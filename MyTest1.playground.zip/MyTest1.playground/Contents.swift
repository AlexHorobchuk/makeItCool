import UIKit

func make(_ string: String) -> String {
    var myWord = ""
    let replace = [ "a" : "@", "o" : "0", "i" : "1", "s" : "$", "t" : "+"]
    string.map { replace[$0.lowercased()] != nil ?
        myWord.append(replace[$0.lowercased()]!) : myWord.append($0)
    }
    return myWord
}

